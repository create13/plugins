<template>
    <div>
        积分评定
    </div>
</template>

<script>
export default {};
</script>

<style scoped>

</style>