<template>
  <div>
      aaaa
  </div>
</template>
<script>
export default {
  data(){
      return {

      }
  }
}
</script>
<style scoped>

</style>

