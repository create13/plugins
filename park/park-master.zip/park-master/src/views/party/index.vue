<template>
    <div>
        党员信息
    </div>
</template>

<script>
export default {};
</script>

<style scoped>

</style>