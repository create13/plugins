import * as axios from './axios';

export default { axios };
