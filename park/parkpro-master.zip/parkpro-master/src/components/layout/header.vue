<template>

  <div class="header">
    <mt-header title="花旗银行第二党支部" style="background-color: #9B0A1A">
      <router-link to="/" slot="left">
        <mt-button icon="back">返回</mt-button>
      </router-link>

    </mt-header>
  </div>
</template>
<script>

export default {
	data(){
		return {

		}
	},
	components:{

	}
}
</script>
<style scoped>

</style>
